### Enconvo  Openai-chatgpt




##### 安装

Enconvo插件商店中找到 Openai-chatgpt，点击安装即可。



##### 不知道Enconvo?

看这里： https://enconvo.com/




