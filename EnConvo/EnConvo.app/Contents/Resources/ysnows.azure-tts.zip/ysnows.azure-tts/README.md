### Enconvo插件-微软TTS(免秘钥)


##### 使用方法


![img.png](assets/img.png)

##### 安装

Enconvo插件商店中找到 微软TTS(开源版)，点击安装即可。



##### 不知道Enconvo?

看这里： https://enconvo.com/



##### 站在巨人的肩膀上

参考： https://github.com/akl7777777/bob-plugin-akl-caiyunxiaoyi-free-translate
