const supportedLanguages = [
    ['auto', 'auto'],
    ['zh-Hans', 'zh-CN'],
    ["zh-Hant", "zh-TW"],
    ['en', 'en-US'],
    ['ja', 'ja-JP'],
    ['ko', 'ko-KR'],
];


exports.supportedLanguages = supportedLanguages;
